"""Train and save the best model from the included CSV."""
from pathlib import Path
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

ROOT = Path(__file__).resolve().parent
df = pd.read_csv(ROOT / "data" / "sample_hotel_bookings.csv")
X, y = df.drop(columns="is_canceled"), df["is_canceled"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
numeric = X.select_dtypes(include="number").columns.tolist()
categorical = X.select_dtypes(exclude="number").columns.tolist()
preprocessor = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                      ("scale", StandardScaler())]), numeric),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical)
])
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
    "Decision Tree": DecisionTreeClassifier(max_depth=8, random_state=42, class_weight="balanced"),
    "Random Forest": RandomForestClassifier(n_estimators=180, max_depth=14,
        min_samples_leaf=2, random_state=42, class_weight="balanced", n_jobs=-1)
}
best_name, best_auc, best_pipe = None, -1, None
for name, model in models.items():
    pipe = Pipeline([("preprocess", preprocessor), ("model", model)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    auc = roc_auc_score(y_test, pipe.predict_proba(X_test)[:, 1])
    print(f"{name}: accuracy={accuracy_score(y_test, pred):.3f}, ROC-AUC={auc:.3f}")
    if auc > best_auc:
        best_name, best_auc, best_pipe = name, auc, pipe
out = ROOT / "models"
out.mkdir(exist_ok=True)
joblib.dump({"model": best_pipe, "model_name": best_name, "features": X.columns.tolist()},
            out / "best_model.joblib")
print(f"Saved {best_name} (ROC-AUC={best_auc:.3f}) to models/best_model.joblib")
