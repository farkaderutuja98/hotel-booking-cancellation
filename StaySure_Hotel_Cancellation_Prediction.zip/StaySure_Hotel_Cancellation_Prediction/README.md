# StaySure Predictor — Hotel Booking Cancellation Prediction

A beginner-friendly machine-learning project with a Streamlit interface.

## Important note about the data
The included `data/sample_hotel_bookings.csv` is **synthetic demonstration data** created so the project runs immediately. It is not the original Hotel Booking Demand dataset and its metrics are not comparable to the website's headline figures. For a genuine academic evaluation, use a verified real dataset with a target column named `is_canceled` (0 = not cancelled, 1 = cancelled).

## Features
- Home page and dataset upload
- Prediction form with cancellation probability
- Dashboard with cancellation distribution and model comparison
- Methodology page
- Comparison of Logistic Regression, Decision Tree and Random Forest
- Missing-value handling, categorical encoding and numerical scaling

## Run on Windows (VS Code)
1. Extract the ZIP file.
2. Open the `StaySure_Hotel_Cancellation_Prediction` folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment:

   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

5. Install packages:

   ```powershell
   py -m pip install -r requirements.txt
   ```

6. Start the app:

   ```powershell
   py -m streamlit run app.py
   ```

7. The app opens in your browser. If it does not, copy the local URL shown in Terminal (usually `http://localhost:8501`).

## Train and save a model separately
Run:

```powershell
py train_model.py
```

The trained pipeline is saved to `models/best_model.joblib`.

## Use your own dataset
Upload a CSV from the Home page. It must have a target column called `is_canceled`, with values 0 and 1. The prediction form supports the feature columns included in the demo CSV; if your dataset has additional columns, adapt the form in `app.py` to collect them.

## Suggested project title
**Hotel Booking Cancellation Prediction Using Machine Learning**

## Academic caution
Do not claim the synthetic demo data represents real hotel booking records. In your report, clearly state the dataset source, preprocessing, train/test split, evaluation results and limitations.
