import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

st.set_page_config(page_title="StaySure Predictor", page_icon="🏨", layout="wide")
st.title("🏨 StaySure Predictor")
st.subheader("Hotel Booking Cancellation Prediction")
st.caption("A machine-learning demonstration project. Predictions are estimates, not guarantees.")

DATA_PATH = "data/sample_hotel_bookings.csv"
MODEL_PATH = "models/best_model.joblib"
TARGET = "is_canceled"

@st.cache_data
def load_data(path):
    return pd.read_csv(path)

def build_pipeline(model, X):
    numeric = X.select_dtypes(include=["number"]).columns.tolist()
    categorical = X.select_dtypes(exclude=["number"]).columns.tolist()
    numeric_pipe = Pipeline([("imputer", SimpleImputer(strategy="median")),
                             ("scaler", StandardScaler())])
    categorical_pipe = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                                 ("onehot", OneHotEncoder(handle_unknown="ignore"))])
    prep = ColumnTransformer([("num", numeric_pipe, numeric),
                              ("cat", categorical_pipe, categorical)])
    return Pipeline([("preprocess", prep), ("model", model)])

@st.cache_resource
def train_models(csv_bytes):
    from io import BytesIO
    data = pd.read_csv(BytesIO(csv_bytes))
    if TARGET not in data.columns:
        raise ValueError("CSV must contain a column named 'is_canceled' (0 = not cancelled, 1 = cancelled).")
    data = data.dropna(subset=[TARGET]).copy()
    X = data.drop(columns=[TARGET])
    y = data[TARGET].astype(int)
    if y.nunique() < 2:
        raise ValueError("The target column must contain both 0 and 1.")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)
    candidates = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Decision Tree": DecisionTreeClassifier(max_depth=8, random_state=42, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(n_estimators=180, max_depth=14,
            min_samples_leaf=2, random_state=42, class_weight="balanced", n_jobs=-1)
    }
    results, fitted = [], {}
    for name, estimator in candidates.items():
        pipe = build_pipeline(estimator, X_train)
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        score = pipe.predict_proba(X_test)[:, 1]
        results.append({"Model": name, "Accuracy": accuracy_score(y_test, pred),
                        "ROC-AUC": roc_auc_score(y_test, score)})
        fitted[name] = pipe
    best_name = max(results, key=lambda r: r["ROC-AUC"])["Model"]
    return data, X.columns.tolist(), X_train, y_test, fitted, pd.DataFrame(results), best_name

with st.sidebar:
    st.header("Project menu")
    page = st.radio("Go to", ["Home", "Predict", "Dashboard", "Methodology"])
    st.divider()
    st.caption("Upload your own Hotel Booking Demand CSV on the Home page to train on real data.")

if "uploaded_bytes" not in st.session_state:
    st.session_state.uploaded_bytes = None

if page == "Home":
    st.write("This application estimates whether a hotel reservation may be cancelled.")
    uploaded = st.file_uploader("Optional: upload a hotel bookings CSV", type=["csv"])
    if uploaded:
        st.session_state.uploaded_bytes = uploaded.getvalue()
        st.success("Dataset uploaded. Open Dashboard or Predict to train and use the models.")
    st.info("The included dataset is synthetic demo data. Replace it with a real dataset for meaningful evaluation.")
    st.markdown("""
    **Included workflow**
    1. Load booking data.
    2. Clean missing values and encode categorical columns.
    3. Compare Logistic Regression, Decision Tree and Random Forest.
    4. Select the model with the highest ROC-AUC score.
    5. Estimate cancellation probability for a new booking.
    """)
    st.markdown("**Target column:** `is_canceled` — 0 = not cancelled, 1 = cancelled.")

else:
    source = st.session_state.uploaded_bytes
    if source is None:
        with open(DATA_PATH, "rb") as f:
            source = f.read()
    try:
        data, features, X_train, y_test, fitted, metrics, best_name = train_models(source)
    except Exception as e:
        st.error(f"Could not train models: {e}")
        st.stop()

    if page == "Predict":
        st.write("Enter booking details. The app will return an estimated cancellation probability.")
        with st.form("prediction_form"):
            c1, c2, c3 = st.columns(3)
            with c1:
                hotel = st.selectbox("Hotel", ["City Hotel", "Resort Hotel"])
                lead_time = st.number_input("Lead time (days)", 0, 1000, 45)
                weekend = st.number_input("Weekend nights", 0, 20, 1)
                week = st.number_input("Week nights", 0, 30, 3)
            with c2:
                adults = st.number_input("Adults", 0, 10, 2)
                children = st.number_input("Children", 0, 10, 0)
                meal = st.selectbox("Meal", ["BB", "HB", "FB", "SC"])
                market = st.selectbox("Market segment", ["Online TA", "Direct", "Groups", "Corporate", "Offline TA"])
            with c3:
                deposit = st.selectbox("Deposit type", ["No Deposit", "Non Refund", "Refundable"])
                customer = st.selectbox("Customer type", ["Transient", "Transient-Party", "Contract", "Group"])
                previous = st.number_input("Previous cancellations", 0, 20, 0)
                special = st.number_input("Special requests", 0, 10, 0)
                adr = st.number_input("Average daily rate", 0.0, 1000.0, 100.0)
            submitted = st.form_submit_button("Predict cancellation risk")
        if submitted:
            row = {
                "hotel": hotel, "lead_time": lead_time, "stays_in_weekend_nights": weekend,
                "stays_in_week_nights": week, "adults": adults, "children": children,
                "meal": meal, "market_segment": market, "deposit_type": deposit,
                "customer_type": customer, "previous_cancellations": previous,
                "total_of_special_requests": special, "adr": adr
            }
            # Align the form row to the exact feature columns of the selected dataset.
            missing = [f for f in features if f not in row]
            if missing:
                st.error("The uploaded dataset has additional feature columns not covered by this form: " + ", ".join(missing))
            else:
                sample = pd.DataFrame([{f: row[f] for f in features}])
                probability = fitted[best_name].predict_proba(sample)[0, 1]
                st.metric("Estimated cancellation probability", f"{probability:.1%}")
                st.progress(float(probability))
                st.write("Higher probability means the model estimates a greater chance of cancellation.")
                st.caption("This is a model estimate, not a confirmed booking outcome.")

    elif page == "Dashboard":
        st.header("Dataset overview")
        a, b, c = st.columns(3)
        a.metric("Bookings", f"{len(data):,}")
        b.metric("Cancellation rate", f"{data[TARGET].mean():.1%}")
        c.metric("Best model (ROC-AUC)", best_name)
        st.subheader("Model comparison")
        st.dataframe(metrics.style.format({"Accuracy": "{:.3f}", "ROC-AUC": "{:.3f}"}), use_container_width=True)
        st.subheader("Cancellation distribution")
        counts = data[TARGET].value_counts().sort_index()
        fig, ax = plt.subplots()
        ax.bar(["Not cancelled (0)", "Cancelled (1)"], [counts.get(0, 0), counts.get(1, 0)])
        ax.set_ylabel("Number of bookings")
        st.pyplot(fig)
        st.caption("Metrics shown are calculated on a held-out test split of the selected CSV.")

    elif page == "Methodology":
        st.header("Methodology")
        st.markdown("""
        **1. Data preparation:** Separate the target `is_canceled` from booking features; impute missing values.

        **2. Encoding:** One-hot encode categorical features and standardize numerical features.

        **3. Train/test split:** Use an 80:20 stratified split to preserve class proportions.

        **4. Algorithms:** Compare Logistic Regression, Decision Tree and Random Forest.

        **5. Evaluation:** Report Accuracy and ROC-AUC on the test set. ROC-AUC measures ranking ability across thresholds.

        **6. Prediction:** Use the best ROC-AUC model to estimate cancellation probability.
        """)
        st.warning("The bundled CSV is synthetic demo data. Do not report its scores as results from the original 119,390-record hotel dataset.")
